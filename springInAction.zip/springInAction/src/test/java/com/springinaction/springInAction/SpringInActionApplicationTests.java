package com.springinaction.springInAction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringInActionApplicationTests {

	@Test
	void contextLoads() {
	}

}
